import React from 'react';

import {API_URL} from "../config";





class Info extends  React.Component {
    constructor(props) {
        console.log(props);
        super();
        this.state = {

            arr: [],
            error: null,
            res:2,
          };
          this.handleChangeSelect = this.handleChangeSelect.bind(this);
        
        }
    
        fetchCurrencies(){
            const {res}=this.state;
            fetch(`${API_URL}/?results=${res}`)
            .then(resp => {
                return resp.json();
            })
            .then(data => {
                console.log(data);
                this.setState({
                    arr:data.results,
                })
            })
            .catch((err)=>{
                console.log(err, 'bhjwbvhjfbvhjkbfv')
            })
        }
    
        componentDidMount(){
           this.fetchCurrencies();
        }
    
        handleChangeSelect (e){
            this.setState({
                res:e.target.value,
            },() => this.fetchCurrencies())
        }
    




render(){
    const {arr , res}=this.state;
    return (
        <div className="div2">
             <select style={{backgroundColor:"white",color:"grey",margin:"25px"}} value={res} onChange={this.handleChangeSelect}>
                <option vlaue="2">2</option>
                <option vlaue="5">5</option>
                <option vlaue="7">7</option>
                <option vlaue="10">10</option>
            </select>
        <div className="div3"  >
            {arr.map((e,index) => {
           return (
            <h1  key={index}>{e.email}</h1>
           )
            })}
            </div>
            <div className="div4">
             {arr.map((e,index) => {
           return (
            <h1  key={index}>{e.phone}</h1>
           )
            })}
            </div>
          
        </div>
        )
    }
}
export default Info;