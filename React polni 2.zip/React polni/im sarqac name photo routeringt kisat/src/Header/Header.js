import React from 'react';

import img from '../Header/img.png';

import { Link } from 'react-router-dom';

import "./Header.css";


const Header = (props) => {
  console.log(props)
    return (
        <div className="navbar navbar-expand-sm bg-dark navbar-dark ">
        
        
        <Link to="/" className="navbar-brand">  <img src={img} alt="logo" className="imgLogo"  />   </Link>
        
     
    
        <ul className="navbar-nav  ">
          <li className="nav-item">
          <Link  to="/arr/:id"  className="nav-link">NameI</Link>
          </li>
          <li className="nav-item">
          <Link to='/arr1/:id'  className="nav-link"> Photo </Link>
          </li>
          <li className="nav-item li3">
          <Link to="/arr2/:id"    className="nav-link"> Info  </Link>
          </li>
        </ul>
    
      </div>
    )
}

export default Header;
