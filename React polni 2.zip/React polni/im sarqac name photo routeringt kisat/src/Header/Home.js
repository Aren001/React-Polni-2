import React from 'react';

import img1 from '../Header/img1.png';



import "./Home.css";



const Home = () => {
    return (
        <div className="sec1">
           <img  src={img1}  className="img1" />
        </div>
    )
}

export default Home