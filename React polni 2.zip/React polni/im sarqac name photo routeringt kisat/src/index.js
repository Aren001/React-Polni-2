import React from 'react';

import ReactDOM from 'react-dom';

import { BrowserRouter, Route, Switch } from 'react-router-dom';

import Header from './Header/Header';

import Home from './Header/Home';

import Name from './section/Name';

import Photo from './section/Photo';

import Info from './section/Info';


const App = () => {
    return (
        <BrowserRouter>
            <Header />
            <Switch>
            <Route  path="/" component={Home} exact />
            <Route  path="/arr/:id" component={Name} />
            <Route  path="/arr1/:id" component={Photo} />
            <Route  path="/arr2/:id" component={Info} />
            </Switch>
        </BrowserRouter>
      
    )
}


ReactDOM.render(<App /> , document.getElementById('root')); 