import React from 'react';
import ReactDOM from 'react-dom';
import FormInput from './FormInput';


const App = () => {
    return (
        <div>
            <FormInput/>
        </div>
    )
}

ReactDOM.render(<App/>,document.getElementById('root'));
