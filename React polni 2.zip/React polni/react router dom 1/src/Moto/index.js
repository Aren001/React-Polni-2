import React from 'react';

const Moto = () => {
    return (
        <div>
            <h2>Moto</h2>
        </div>
    )
};
export default Moto;
 