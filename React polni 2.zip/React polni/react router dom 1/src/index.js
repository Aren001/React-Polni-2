import React from 'react';
import ReactDOM from 'react-dom';
import Header from './Header/Header';
import { BrowserRouter,  Switch, Route } from 'react-router-dom';
import Home from './Home';
import Moto from './Moto';
import CarDetail from './CarDetail';
import Car from './Car';
const App = () => {
    return(
        <div>
            <BrowserRouter >
            <Header />

                <Switch>
                    {/* vori vra sexmem en componenty ereva is path-y  searchum /componenti anunna apahovum */}
                    <Route path='/' component={Home} exact/>   
                    <Route path='/moto' component={Moto} />
                    <Route path='/car' component={Car} exact/>
                    <Route path='/car/:id' component={CarDetail} />
                </Switch>
        
            </BrowserRouter>
        </div>
    )
}

ReactDOM.render(
    <App/>,
    document.getElementById("root")
)