import React from 'react';
import { carData } from '../carData';
import { Link } from 'react-router-dom';

const Car = () => {
    return (
        <div>
            <h2>Car</h2>
            <ul>
            {
                carData.map(car => (
                    <li><Link to={`car${car.link}`}>{car.name}</Link></li>
                ))
            }
            </ul>
        </div>
    )
};
export default Car;