import React from 'react';


const CarDetail = (props) => {
    console.log(props);//propsi meja pastoren
    return (
        <div>
            <h2>{props.match.params.id.toUpperCase()}</h2>
           
        </div>
    )
};
export default CarDetail;