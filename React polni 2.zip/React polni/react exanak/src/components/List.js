import React from 'react';

import Loading from './Loading';

import {API_URL} from '../config';

import {API_KEY} from '../config';

import Teg from './esim';

class List extends React.Component {
    constructor(){
        super();
        this.state={
        temperatura:null,
        city: null,
        country:null,
        icon: null,
        inputValue:"",
        flags: null,
        iconTemp: null,
        loading:false
        }
        
        this. handleChange = this. handleChange.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
    }


    fetchCurrencies(){
        
        const {inputValue , loading}=this.state;
        this.setState({
            loading:true,
        })
        if(inputValue  ){
        fetch(`${API_URL}${inputValue}&appid=${API_KEY}&units=metric`)
        .then(resp => {
            //  console.log(resp);
            return resp.json();})
        .then(data => {
                // console.log(data);
                this.setState({
                    loading:false,
                    temperatura: Math.round(data.main.temp),
                    city:data.name,                    
                    country: data.sys.country,
                    flags: `https://www.countryflags.io/${data.sys.country}/flat/64.png`,
                    iconTemp: `http://openweathermap.org/img/w/${data.weather[0].icon}.png`,
                })
        
            })

            .catch(err => {
                console.log('ERRORR', err)
                this.setState({
                    temperatura: null,
                    city:null,                    
                    country:null,
                    flags:null,
                    loading:false,
                    inputValue:''
                })
                alert('Erorr')
            })

        }else { this.setState({
            temperatura: null,
            city:null,                    
            country:null,
            flags:null,
            loading:false,
        })
           
        }
       
    }

   
    handleChange(event) {
        this.setState({inputValue: event.target.value});
    };
    
    handleSubmit(event) {
        const {inputValue} = this.state;
        this.setState({
            inputValue: this.state.inputValue
        }, () => {
            this.fetchCurrencies();
        });
        if(inputValue == "") {
            alert('Please enter the city name');
        }
        else if(inputValue == null){
            alert('Erorr')
        }
        event.preventDefault();
      };

    

    render(){
        const {temperatura , city , country, flags, iconTemp , loading} = this.state;
      
        
        return (
            <div > 
            <div className="App">
                <div className="form">

                    <form onSubmit={this.handleSubmit}>

                        <input className="input1"
                         type="text"
                         placeholder="City"
                         type="text"
                         value={this.state.inputValue} 
                         onChange={this.handleChange} />

                        <button type='submit' className="but1"  value="Submit" > Search   </button>

                    </form>
                    {/* loadingi dzevy nayi .............................................................. */}
                    <div className="p30"><div className="div20">{ loading ? <Loading/> : false }</div></div>
                    <p id="errorMessage"></p>
                </div>
                
                <div className="div-2">
                    <ul className='informationList'>
                        <li>
                            <span id="city">{city}</span>
                            <span><i className="fa fa-map-marker" aria-hidden="true"></i></span>
                            <span>City</span>
                        </li>
                        <li>
                            <span  id="country">{country}</span>
                            <span><img src={flags} id="CountryId" /></span>
                            <span>Country</span>
                        </li>
                        <li>
                            <span className="temp">{temperatura}</span>
                            <span> <img src={iconTemp}  /> </span>
                            <span><i className="fa fa-thermometer" /></span>
        <span>Temperature   </span>
                        </li>
        
                    </ul>
                    
                   
                </div>
               
                </div>
                
            <Teg/>
            </div>
        )
    }
}

export default List;