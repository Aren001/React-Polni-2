import React from "react";
import { API_URL } from "../../config";
import Table from './Table';
import Loading from ".././common/Loading";
import Pagination from './Pagination';
import Select from './Select';
import "./Table.css";

class List extends React.Component {
  constructor() {
    super();
    this.state = {
      loading: false,
      currencies: [],
      error: null,
      perPage: 10,
      page : 1,
      totalPages : 0
    };
    this.handlePaginationClick = this.handlePaginationClick.bind(this);
    this.handlChangeSelect=this.handlChangeSelect.bind(this);
  }
  fetchCurencies(){
    const { perPage, page } = this.state;
    this.setState({
      loading: true
    });

    fetch(`${API_URL}/cryptocurrencies/?page=${page}&perPage=${perPage}`)
      .then(resp => {
        return resp.json().then(data => {
          if(resp.ok) {
              return data
          }else {
            return Promise.reject(data)
          }
        })
      })
      .then(data => {
        this.setState({
          loading: false,
          currencies: data.currencies,
          totalPages : data.totalPages
        })
      })
      .catch((err)=>{
          console.log(err, 'bhjwbvhjfbvhjkbfv')
      })
  }

  componentDidMount() {
    this.fetchCurencies()
  }
  //PAGINATION
  handlePaginationClick(direction){ 
    let nextPage = this.state.page;
    nextPage = direction === 'next'? nextPage + 1 : nextPage - 1;
    this.setState({   //dzevy nayi  senca arac vor fetchnel hety havasar ashxati ansinxromi momentna
      page:nextPage
    }, () => {
      this.fetchCurencies();
    });
  };

//    //SELECT
//    handlChangeSelect(e) {
//     // console.log(e);
//     this.setState({
//         perPage:e.target.value,
//     },() => {
//       this.fetchCurrencies()})
// }

handlChangeSelect(e){
    this.setState({
      perPage:e.target.value,
    },() => this.fetchCurencies() )
}

  render() {
    const { loading, currencies, error  , page , totalPages , perPage} = this.state;
    if (loading) {
      return (
        <div className="loading-container">]
          <Loading />
        </div>
      );
    }
    
    return (
      <div>
        <Select handlChangeSelect={this.handlChangeSelect}  perPage={perPage}  />
        <Table currencies={currencies}/>
        <Pagination 
          page={page}
          totalPages={totalPages}
          handlePaginationClick={this.handlePaginationClick}
        />
      </div>
    );
  }
};
export default List;
