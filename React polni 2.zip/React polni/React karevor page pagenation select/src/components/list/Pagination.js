import React from 'react';
import './Pagination.css';

const Pagination = ({page , totalPages , handlePeginationClick}) => {
    return (
        <div className="Pagination">
            <button
                onClick={() => handlePeginationClick('prev')}
                disabled = {page === 1}
                className="Pagination-button"
            >
                &larr;
            </button>
            <span className="Pagination-info">
                Page <b>{page}</b> of <b>{totalPages}</b>
            </span>
            <button
               
                onClick={() => handlePeginationClick('next')}
                disabled  = {page === totalPages}
                className="Pagination-button"
            >
                &rarr;
            </button>
        </div>
    )
};
export default Pagination;