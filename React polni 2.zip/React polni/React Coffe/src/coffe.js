import React from 'react';

import o1  from './images/o1.jpg';
import o2  from './images/o2.jpg';
import o3  from './images/o3.jpg';
import cof from './images/cof.png';
import zda from './images/zda.gif';
import cofno from './images/cofno.jpg';



class Coffe extends React.Component {
    constructor() {
        super();
        this.state={
            inputvalue:'',
            nume:'Enter Money',
            zdach:'',
            nka:false,
            kopek:false,
            zvuk1:false,
            zvuk2:false,
           
            
        }
        this.handlechange=this.handlechange.bind(this);
        this.handlesubmit=this.handlesubmit.bind(this);
        
        this.but=this.but.bind(this);
    }
    

    handlechange (e) {
        this.setState({
            inputvalue:e.target.value,
        })
       
        
    }


    handlesubmit (e) {
        e.preventDefault();
    }
  


    but(num) {
        const {inputvalue }=this.state;
        if(inputvalue==num)
       {

        this.setState({
            nume:'Loading'
        })

        setTimeout(() => {this.setState({
            nume:'Preparing',
            nka:true,
            zvuk1:true,
        })},2000)

        setTimeout(()=>{
            this.setState({
                inputvalue:'',
                nume:"Ready",
                nka:false,
                zvuk1:false,

            })
        },8000)


        setTimeout(() => {
            this.setState({
                nume:'Entner Money',
            })
        },13000)

       }else if(inputvalue > num){
        this.setState({
            nume:'Loading'
        })

        setTimeout(() => {this.setState({
            nume:'Preparing',
            nka:true,
            zvuk1:true,
        })},2000)

        setTimeout(()=>{
            this.setState({

                inputvalue:'',
                nume:"Ready",
                zdach:num-inputvalue,
                nka:false,
                kopek:true,
                zvuk2:true,
                zvuk1:false,
            })
        },8000)


        setTimeout(() => {
            this.setState({
                nume:'Entner Money',
                zvuk2:false,
                kopek:false,
                zdach:'',
            })
        },13000)
       }

       else if(inputvalue < num && inputvalue!=''){

        this.setState({
            nume:'Loading'
        })

        setTimeout(() => {this.setState({
            nume:`EroR Coffe - ${num} `,
            zdach:inputvalue,
            kopek:true,
            zvuk2:true,
        })},2000)
       }
       setTimeout(()=>{
        this.setState({

            inputvalue:'',
            nume:"Enter Money",
            zdach:'',
            kopek:false,
            zvuk2:false,
        })
    },6000)



    }

    render() {
        const {inputvalue , nume , zdach , nka , kopek , zvuk1 , zvuk2 }=this.state;
        return (
            <div className="sec1">

                <div>

                <div className='div1'>

                    <div><img className="img1" src={o1} /></div>

        <div className='p1'><p>{nume}   <h6 style={{position:'absolute',right:'1100px',top:'260px'}}>{inputvalue}</h6> </p></div>


                    <div className='div4'>

                       <div className='div5'>

                       <div><h4>200 DR</h4><button   onClick={() => this.but(200)} ></button></div>

                           <div><h4>350 DR</h4> <button onClick={() => this.but(350)} ></button>  </div>

                           <div><h4>500 DR</h4> <button onClick={() => this.but(500)} ></button>  </div>

                           <div><h4>650 DR</h4> <button onClick={() => this.but(650)} ></button>   </div>

                       </div>

                       <div className="div6">

                        <form onSubmit={this.handlesubmit}>
                            <input  value={inputvalue} onChange={this.handlechange}            type='text' className="div7" placeholder="Enter Money" />

                    </form>
                            <img src={o2} className="img2" />


        <div className="div8">{zdach}</div>


                       </div>

                    </div>

                    <div><img className="img3" src={o3} /></div>

                </div>
                
                </div>

                <div > 
                    {zvuk2 ? <audio src="/audio/03928.mp3" controls autoPlay></audio> : null }  <br/> 
                    {zvuk1 ? <audio src="/audio/water-pour-liquid-into-styrofoam-cup-coffee_zy_fi2nu.mp3" controls autoPlay></audio> : null }
                 <div>
                <div>  {nka ? <img src={cof} className='img4' /> : <img src={cofno}  className='img4' /> }    </div>
                <div>   {kopek ? <img className='img5' src={zda} /> : <div className='img5' style={{backgroundColor:'white'}} ></div>  } </div>
                </div>

                </div>

             
                
                
                
            </div>
  
        
    
            
        )
    }
}

export default Coffe;