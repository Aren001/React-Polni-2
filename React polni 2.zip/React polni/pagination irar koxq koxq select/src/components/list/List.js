import React from 'react';

import { API_URL } from '../../config';

import Table from './Table';

import Loading from '../common/Loading';

import Pagination from './Pagination';

import Select from './Select';

import './Table.css';


class List extends React.Component {
    constructor() {
        super();
        this.state = {
            loading: false,
            currencies: [],
            error: null,
            perPage:10,
            page:1,
            totalPages:0,
        }
        this.handlePeginationClick=this.handlePeginationClick.bind(this);
        this.handlChangeSelect=this.handlChangeSelect.bind(this);
    }

    //VOR ANYNDHAY FETCH ANI ERB KANCHENQ
    fetchCurrencies() {
        const {perPage , page}=this.state;
        this.setState({
            loading: true,
        })
        fetch(`${API_URL}/cryptocurrencies/?page=${page}&perPage=${perPage}`)
            .then(resp => {
                //  console.log(resp);
                return resp.json()
                    .then(json => {
                        if (resp.ok) {
                            return json
                        } else {
                            return Promise.reject(json);
                        }
                    })
            })
            .catch(eror => {
                // console.log(eror)
            })
            .then(data => {
                // console.log(data);
                // console.log(data.currencies);
                this.setState({
                    loading: false,
                    currencies: data.currencies,
                    totalPages:data.totalPages,
                })
            })
    }
    componentDidMount() {
        this.fetchCurrencies();
    }

    //PEGINATION  Page-rov irar koxq
    handlePeginationClick (pagenumber) {
        // alert(direction);
        this.setState({
            page:pagenumber,
        },() =>  this.fetchCurrencies() 
        )
    }

    //SELECT
    handlChangeSelect(e) {
        // console.log(e);
        this.setState({
            perPage:e.target.value,
        },() => this.fetchCurrencies())
    }



    render() {
      //const { loading, currencies, error , page , totalPages , perPage } = this.state;// tvelenq vor ashxati ete sra mej chgrenq this.state.perpage
        const { loading, currencies, error , page , totalPages , perPage } = this.state;
        console.log(this.state);
        if (loading) {
            return (
                <div className="loading-container">
                    <Loading />
                </div>
            )
        }
        return (
            <div >
                <Select handlChangeSelect={this.handlChangeSelect}  perPage={perPage}  />
                <Table currencies={currencies}   />
                <Pagination page={page} totalPages={totalPages}  handlePeginationClick={this.handlePeginationClick} />
            </div>
        )
    }
}
export default List;
