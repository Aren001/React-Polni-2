import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';


const Dpp = () => {
    return(
       <div> <App /> </div>
    )
}

ReactDOM.render(
    <Dpp/>,
    document.getElementById("root")
)